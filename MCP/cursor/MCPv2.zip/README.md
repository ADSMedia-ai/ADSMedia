# ADSMedia MCP Server

MCP (Model Context Protocol) сервер для интеграции [ADSMedia Email API](https://www.adsmedia.ai/api-docs) с Cursor IDE.

## 🚀 Возможности

Полный доступ к ADSMedia API через MCP:

### 📧 Email
- **Отправка писем** — транзакционные и маркетинговые
- **Batch отправка** — до 1000 получателей за раз с персонализацией
- **Статус отправки** — отслеживание доставки

### 📑 Кампании
- Создание, редактирование, удаление кампаний
- HTML шаблоны с плейсхолдерами

### 📋 Списки и Контакты
- Управление списками подписчиков
- Добавление/удаление контактов
- Кастомные поля

### 📅 Расписания
- Создание задач на отправку
- Пауза/возобновление/остановка

### 🖥️ Серверы
- Просмотр серверов отправки
- Статус и лимиты

### 🌐 Верификация доменов
- Проверка SPF, DKIM, DMARC, MX, PTR
- DNSSEC и TLSA валидация

### 📊 Статистика
- Общая статистика
- По кампаниям
- Почасовая/дневная разбивка
- География открытий
- Отказы и провайдеры

### ⚡ События
- Opens, clicks, bounces, unsubscribes

### 🚫 Suppression
- Проверка заблокированных email

### 👤 Аккаунт
- Информация об аккаунте
- Использование и лимиты
- API ключи

---

## 📦 Установка

### 1. Клонируйте репозиторий

```bash
git clone <repo-url>
cd adsmedia-mcp
```

### 2. Установите зависимости

```bash
npm install
```

### 3. Соберите проект

```bash
npm run build
```

---

## ⚙️ Настройка Cursor IDE

### Вариант 1: Глобальная конфигурация

Откройте глобальный файл конфигурации MCP:
- **Windows:** `%APPDATA%\Cursor\User\globalStorage\cursor.mcp\config.json`
- **macOS:** `~/Library/Application Support/Cursor/User/globalStorage/cursor.mcp/config.json`
- **Linux:** `~/.config/Cursor/User/globalStorage/cursor.mcp/config.json`

Добавьте конфигурацию:

```json
{
  "mcpServers": {
    "adsmedia": {
      "command": "node",
      "args": ["C:/path/to/adsmedia-mcp/dist/index.js"],
      "env": {
        "ADSMEDIA_API_KEY": "ваш_api_ключ"
      }
    }
  }
}
```

### Вариант 2: Конфигурация проекта

Создайте файл `.cursor/mcp.json` в корне вашего проекта:

```json
{
  "mcpServers": {
    "adsmedia": {
      "command": "node",
      "args": ["C:/path/to/adsmedia-mcp/dist/index.js"],
      "env": {
        "ADSMEDIA_API_KEY": "ваш_api_ключ"
      }
    }
  }
}
```

> ⚠️ **Важно:** Замените `C:/path/to/adsmedia-mcp` на реальный путь к папке проекта.

---

## 🔑 Получение API ключа

1. Зарегистрируйтесь на [adsmedia.ai](https://www.adsmedia.ai)
2. Перейдите в настройки аккаунта
3. Скопируйте ваш API ключ

---

## 🛠️ Доступные инструменты (Tools)

### Authentication
| Tool | Описание |
|------|----------|
| `adsmedia_ping` | Проверка соединения с API |

### Email
| Tool | Описание |
|------|----------|
| `adsmedia_send_email` | Отправить транзакционное письмо |
| `adsmedia_send_batch` | Отправить batch маркетинговых писем |
| `adsmedia_send_status` | Получить статус отправки |

### Campaigns
| Tool | Описание |
|------|----------|
| `adsmedia_list_campaigns` | Список кампаний |
| `adsmedia_get_campaign` | Получить кампанию по ID |
| `adsmedia_create_campaign` | Создать кампанию |
| `adsmedia_update_campaign` | Обновить кампанию |
| `adsmedia_delete_campaign` | Удалить кампанию |

### Lists & Contacts
| Tool | Описание |
|------|----------|
| `adsmedia_list_lists` | Список списков подписчиков |
| `adsmedia_create_list` | Создать список |
| `adsmedia_get_contacts` | Получить контакты из списка |
| `adsmedia_add_contacts` | Добавить контакты |
| `adsmedia_delete_contacts` | Удалить контакты |

### Schedules
| Tool | Описание |
|------|----------|
| `adsmedia_list_schedules` | Список задач |
| `adsmedia_create_schedule` | Создать задачу |
| `adsmedia_pause_schedule` | Приостановить задачу |
| `adsmedia_resume_schedule` | Возобновить задачу |
| `adsmedia_stop_schedule` | Остановить задачу |

### Servers
| Tool | Описание |
|------|----------|
| `adsmedia_list_servers` | Список серверов |
| `adsmedia_get_server` | Информация о сервере |

### Domain Verification
| Tool | Описание |
|------|----------|
| `adsmedia_verify_domain` | Проверка DNS записей |

### Statistics
| Tool | Описание |
|------|----------|
| `adsmedia_stats_overview` | Общая статистика |
| `adsmedia_stats_campaign` | Статистика кампании |
| `adsmedia_stats_hourly` | Почасовая статистика |
| `adsmedia_stats_daily` | Дневная статистика |
| `adsmedia_stats_countries` | География |
| `adsmedia_stats_bounces` | Отказы |
| `adsmedia_stats_providers` | По провайдерам |

### Events
| Tool | Описание |
|------|----------|
| `adsmedia_get_events` | Получить события |

### Suppressions
| Tool | Описание |
|------|----------|
| `adsmedia_check_suppression` | Проверить email на блокировку |

### Account
| Tool | Описание |
|------|----------|
| `adsmedia_get_account` | Информация об аккаунте |
| `adsmedia_get_usage` | Использование и лимиты |
| `adsmedia_get_api_keys` | Получить API ключ |
| `adsmedia_regenerate_api_key` | Сгенерировать новый API ключ |

---

## 📝 Примеры использования

### Отправка письма

```
Отправь письмо на test@example.com с темой "Привет" и текстом "<h1>Hello!</h1>"
```

### Создание кампании

```
Создай кампанию "Новогодняя рассылка" с темой "С Новым Годом!" и HTML контентом
```

### Получить статистику

```
Покажи статистику кампании с ID 123
```

### Проверить сервер

```
Проверь DNS записи для сервера 15
```

---

## 🔗 Ссылки

- [ADSMedia API Documentation](https://www.adsmedia.ai/api-docs)
- [ADSMedia Website](https://www.adsmedia.ai)
- [MCP Protocol](https://modelcontextprotocol.io)
- [Cursor IDE](https://cursor.com)

---

## 📄 Лицензия

MIT

